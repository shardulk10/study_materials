<div class="slider clearfix">
         <div class="fullwidthbanner-container">
          <div id="revolution-slider-home-3" class="slider-home-5">
            <ul>
              <!-- SLIDE  -->
              <li data-transition="fade" data-slotamount="7" data-masterspeed="1500" >
                  <!-- MAIN IMAGE -->
                  <img src="<?php echo base_url(); ?>assets/frontend/images/Slider/5.jpg"  alt="slidebg1"  data-bgfit="cover" data-bgposition="center" data-bgrepeat="no-repeat">

                  <!-- LAYER NR. 1 -->
                  <div class="tp-caption sfb h1-text text-white text-cap"
                    data-x="55"
                    data-y="178"
                    data-speed="500"
                    data-start="800"
                    data-easing="easeInOutCubic"

                    >Finance Consulting
                  </div>

                  <!-- LAYER NR. 3 -->
                  <div class="tp-caption sfb h3-text text-white text-light"
                    data-x="55"
                    data-y="236"

                    data-speed="500"
                    data-start="1000"
                    data-easing="easeInOutCubic"
                   style="max-width: 565px">
                     Comprehensive financial advice and financial services<br>
                     that are tailored to meet your individual needs
                  </div>
                  <!-- LAYER NR. 4 -->
                  <!-- <div class="tp-caption sfb group-btn-slider"
                    data-x="55"
                    data-y="351"

                    data-speed="500"
                    data-start="1400"
                    data-easing="easeInOutCubic"
                    > <a href="services.html" class="ot-btn large-btn btn-rounded btn-main-color btn-1">Our Services</a>
                    <a href="services.html" class="ot-btn large-btn btn-rounded btn-border-ghost btn-2">Get Free Call Back</a>
                  </div>-->
              </li>
               <!-- SLIDE  -->
               <li data-transition="fade" data-slotamount="7" data-masterspeed="1500" >
                  <!-- MAIN IMAGE -->
                  <img src="<?php echo base_url(); ?>assets/frontend/images/Slider/7.jpg"  alt="slidebg1"  data-bgfit="cover" data-bgposition="center" data-bgrepeat="no-repeat">

                  <!-- LAYER NR. 1 -->
                  <div class="tp-caption sfb h1-text text-white text-cap"
                    data-x="55"
                    data-y="178"
                    data-speed="500"
                    data-start="800"
                    data-easing="easeInOutCubic"

                    >We are Experienced Experts
                  </div>

                  <!-- LAYER NR. 3 -->
                  <div class="tp-caption sfb h3-text text-white text-light"
                    data-x="55"
                    data-y="236"

                    data-speed="500"
                    data-start="1000"
                    data-easing="easeInOutCubic"
                   style="max-width: 565px">
                     Comprehensive financial advice and financial services<br>
                     that are tailored to meet your individual needs
                  </div>
                  <!-- LAYER NR. 4 -->
                   <!--<div class="tp-caption sfb group-btn-slider"
                    data-x="55"
                    data-y="351"

                    data-speed="500"
                    data-start="1400"
                    data-easing="easeInOutCubic"
                    > <a href="services.html" class="ot-btn large-btn btn-rounded btn-main-color btn-1">Our Services</a>
                    <a href="services.html" class="ot-btn large-btn btn-rounded btn-border-ghost btn-2">Get Free Call Back</a>
                  </div>-->
              </li>
              <!-- SLIDE  -->
               <li data-transition="fade" data-slotamount="7" data-masterspeed="1500" >
                  <!-- MAIN IMAGE -->
                  <img src="<?php echo base_url(); ?>assets/frontend/images/Slider/14.jpg"  alt="slidebg1"  data-bgfit="cover" data-bgposition="center" data-bgrepeat="no-repeat">

                  <!-- LAYER NR. 1 -->
                  <div class="tp-caption sfb h1-text text-white text-cap"
                    data-x="55"
                    data-y="178"
                    data-speed="500"
                    data-start="800"
                    data-easing="easeInOutCubic"

                    >Investment outlook
                  </div>

                  <!-- LAYER NR. 3 -->
                  <div class="tp-caption sfb h3-text text-white text-light"
                    data-x="55"
                    data-y="236"

                    data-speed="500"
                    data-start="1000"
                    data-easing="easeInOutCubic"
                   style="max-width: 565px">
                     Comprehensive financial advice and financial services<br>
                     that are tailored to meet your individual needs
                  </div>
                  <!-- LAYER NR. 4 -->
                 <!--  <div class="tp-caption sfb group-btn-slider"
                    data-x="55"
                    data-y="351"

                    data-speed="500"
                    data-start="1400"
                    data-easing="easeInOutCubic"
                    > <a href="services.html" class="ot-btn large-btn btn-rounded btn-main-color btn-1">Our
                    </a>
                    <a href="services.html" class="ot-btn large-btn btn-rounded btn-border-ghost btn-2">Get Free Call Back</a>
                  </div>-->
              </li>
            </ul>
          </div>
        </div>
    </div><!-- Revoslider End -->

  <section>
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-md-6">
                    <div class="video-intro-container">
                        <div class="background-video">
                              <img src="<?php echo base_url(); ?>assets/frontend/images/About/bg-about.jpg" class="images-responsive" alt="Image">
                             <!-- <button data-href="https://www.youtube.com/embed/vOAB6XOkY2E" id="btn-event" class="btn btn-play" ></button >-->
                        </div>



                    </div>
                </div>
                <div class="col-xs-12 col-md-6">
                  <h2>Welcome To Maxima Ventures LLP</h2>
                  <div class="clearfix"></div>
                  <?php echo $home_short_about_us->body_content;?>

        <a class="ot-btn  btn-main-color default-size-btn" href="<?php echo base_url(); ?>about_us">Read More</a>
              </div><!-- End col -->
            </div><!-- End row -->
        </div><!-- End container-->
    </section><!-- End section-->



     <!-- Component Thumbnail Left Icon SVG -->
    <div class="padding-top-65 padding-bottom-65 bg-grey">
      <div class="container">

   <h2 class="title text-center margin-bottom-40">Our Services</h2>
          <div class="row clearfix">
            <div class="col-md-12">
              <article class=" col-sm-6 col-md-3 thumbnail-style thumbnail-icon-item text-center ">

                   <div class="thumbnail">
                      <img class="img-icon-thumbnail" src="<?php echo base_url(); ?>assets/frontend/images/Services/1.png" alt="">
                     <div class="caption">
                       <h4>Portfolio Analysis</h4>
                       <p>
                        People invest saved amounts in different instruments this pool of such ...<a href="<?php echo base_url(); ?>service">Read More</a>
                        </p>

                     </div>
                   </div>

              </article><!-- End article -->
              <article class=" col-sm-6 col-md-3 thumbnail-style thumbnail-icon-item text-center ">

                   <div class="thumbnail">
                       <img class="img-icon-thumbnail" src="<?php echo base_url(); ?>assets/frontend/images/Services/2.png" alt="">
                     <div class="caption">
                       <h4>Retirement Planning</h4>
                       <p>
                        Most of us dream to 'Retire Sooner, Retire Richer!'However, it's a far-fetched dream ...<a href="<?php echo base_url(); ?>service">Read More</a> 
                       </p>

                     </div>
                   </div>

              </article><!-- End article -->
              <article class=" col-sm-6 col-md-3 thumbnail-style thumbnail-icon-item text-center ">

                   <div class="thumbnail">
                       <img class="img-icon-thumbnail" src="<?php echo base_url(); ?>assets/frontend/images/Services/3.png" alt="">
                     <div class="caption">
                       <h4>Taxes Planning</h4>
                       <p>
                        Along with your income what grows is tax liability. Thankfully, the government ...<a href="<?php echo base_url(); ?>service">Read More</a>
                       </p>

                     </div>
                   </div>

              </article><!-- End article -->
               <article class=" col-sm-6 col-md-3 thumbnail-style thumbnail-icon-item text-center ">

                 <div class="thumbnail">
                     <img class="img-icon-thumbnail" src="<?php echo base_url(); ?>assets/frontend/images/Services/6.png" alt="">
                   <div class="caption">
                     <h4>Home Buying</h4>
                     <p>
                      A man's home is his castle! In other words, it gives you rightful roof and immense ...<a href="<?php echo base_url(); ?>service">Read More</a>
                     </p>

                   </div>
                 </div>

            </article><!-- End article -->

            </div>

          </div><!-- End Row -->
       <a class="mid-btn  btn-main-color default-size-btn margin-top-40"  href="<?php echo base_url(); ?>service">Read More</a>
      </div><!-- End container -->
    </div> <!-- End section -->

    <!-- Component Courter Up -->
    <section>
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <div class="counter-up counter-up-style-1 text-center">
                  <h2>We are help you to grow your wealth</h2>
                  <?php echo $home_grow_business->body_content;?>

                  <ul>
                    <li>
                      <p><span class="couterup" id="yoe"></span></p>
                      <span class="label-counter">Years of experience</span>
                    </li>
                    <li>
                      <p><span class="couterup" id="hc"></span><span class="unit">K</span></p>
                      <span class="label-counter">Happy Customers</span>
                    </li>
                    <li>
                      <p><span class="couterup" id="satis"></span><span class="unit">%</span></p>
                      <span class="label-counter">Satisfaction</span>
                    </li>
                  </ul>
                </div><!-- End counter up -->
              </div> <!-- End cold -->
              <a class="mid-btn  btn-main-color default-size-btn margin-top-40"  href="<?php echo base_url(); ?>grow_your_welth">Read More</a>
            </div><!-- End row -->
            
          </div><!-- End container -->
    </section><!-- End Section -->
     <!-- Component Accrodion -->
    <!--section class="our-process bg-dark no-padding">
         <div class="row">
            <div class="process-warp">
              <div class="col-md-6 col-lg-6 img-demo-our-process">
                <img src="<?php echo base_url(); ?>assets/frontend/images/Process/1.jpg" class="img-responsive" alt="Image">
             </div>
             <div class="col-md-6 col-lg-6 accordion-process padding-top-70 padding-bottom-50">
                 <div class="accordion-style-light no-round">
                <div class="accordion-warp">
                  <h2 class="title text-white">Why Choose Us</h2>
                  <div class="clearfix"></div>
                  <div class="panel-group" id="accordion2">
                  <div class="panel panel-default">
                      <div class="panel-heading">
                          <h4 class="panel-title">
                              <a data-toggle="collapse" data-parent="#accordion2" href="#collapseOne2">01. Define Objectives</a>
                          </h4>
                      </div>
                      <div id="collapseOne2" class="panel-collapse collapse in">
                          <div class="panel-body">
                            <div class="accordion-content">
                              <?php echo $define_objectives->body_content;?>

                            </div>
                          </div>
                      </div>
                  </div>
                  <div class="panel panel-default">
                      <div class="panel-heading">
                          <h4 class="panel-title">
                              <a data-toggle="collapse" data-parent="#accordion2" href="#collapseTwo2" class="collapsed">02. Develop a Plan</a>
                          </h4>
                      </div>
                      <div id="collapseTwo2" class="panel-collapse collapse">
                          <div class="panel-body">
                              <div class="accordion-content">
                              <?php echo $develop_a_plan->body_content;?>
                            </div>
                          </div>
                      </div>
                  </div>
                  <div class="panel panel-default">
                      <div class="panel-heading">
                          <h4 class="panel-title">
                              <a data-toggle="collapse" data-parent="#accordion2" href="#collapseThree2" class="collapsed">03. Implementation</a>
                          </h4>
                      </div>
                      <div id="collapseThree2" class="panel-collapse collapse">
                          <div class="panel-body">
                              <div class="accordion-content">
                              <?php echo $implementation->body_content;?>
                            </div>
                          </div>
                      </div>
                  </div>
                  <div class="panel panel-default">
                      <div class="panel-heading">
                          <h4 class="panel-title">
                              <a data-toggle="collapse" data-parent="#accordion2" href="#collapseFour2" class="collapsed">04. Monitor Results</a>
                          </h4>
                      </div>
                      <div id="collapseFour2" class="panel-collapse collapse">
                          <div class="panel-body">
                              <div class="accordion-content">
                              <?php echo $monitor_results->body_content;?>
                            </div>
                          </div>
                      </div>
                  </div>
                  </div--> <!-- End panel group -->

          <!--a class="ot-btn midium-btn btn-light btn-read margin-top-20" href="abouts.html#why-choose-us">Read More</a>
                </div>
            </div>

             </div--> <!-- End Col -->
            <!--/div>
         </div--> <!-- End Row -->
    <!--/section--> <!-- End container -->
    <!-- Testimonial 3 column -->
    <section class="bg-grey">
      <div class="container">
        <div class="row">
    <div class="col-md-12 col-center m-auto">
      <h2 class="text-center">Testimonials</h2>
      <div id="myCarousel" class="carousel slide" data-ride="carousel">
        <!-- Carousel indicators -->
        <ol class="carousel-indicators">
          <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
          <li data-target="#myCarousel" data-slide-to="1"></li>
          <li data-target="#myCarousel" data-slide-to="2"></li>
        </ol>
        <!-- Wrapper for carousel items -->
        <div class="carousel-inner">
          
          <?php
            $i = 0; 
            foreach($home_testimonials AS $key=>$row) {
            $defaultClass = "";
            if($i == 0) {
            $defaultClass = "active";
            }
          ?>
          <div class="item carousel-item <?php echo $defaultClass;?>">
            <div class="img-box"><img src="<?php echo $row->image_path;?>" height="50" width="50"  alt="<?php echo $row->name;?>"></div>
            <p class="testimonial"><?php echo $row->intro;?></p>
            <p class="overview"><b><?php echo $row->name;?></b></p>
          </div>
          <?php
              $i++; 
              } 
          ?>
          
        </div>
        <!-- Carousel controls -->
        <a class="carousel-control left carousel-control-prev" href="#myCarousel" data-slide="prev">
          <i class="fa fa-angle-left"></i>
        </a>
        <a class="carousel-control right carousel-control-next" href="#myCarousel" data-slide="next">
          <i class="fa fa-angle-right"></i>
        </a>
      </div>
    </div>
  </div><!-- End row -->
   <a href="<?php echo base_url(); ?>testimonials" class="mid-btn  btn-main-color default-size-btn margin-top-40" >Read More</a>
      </div><!-- End container -->
    </section><!-- End section -->

    <!-- Component Progress Bar -->
    <section class="no-padding">
        <div class="container">
          <div class="row">
              <div class="overflow-hidden">
                    <div class="col-md-6 col-lg-6 padding-top-70 padding-bottom-35">
                      <div class=" bar-chart-container " style="text-align:justify">
                        <h2 class="clearfix">Our Commitment</h2>

                        <?php echo $our_commitment->body_content;?>

                        <div class="chart-2 chart-2-v">
                            <div style="" class="chart-v-item">

                                <span class="percent-v update-v"></span>
                                <div class="progress  vertical bottom progress-v">
                                    <div class="progress-bar bar-chart" role="progressbar" data-transitiongoal="80"></div>
                                </div>
                                <span class="label-v">PARTNERSHIP</span>
                            </div>
                            <div style="" class="chart-v-item">

                                <span class="percent-v update-v"></span>
                                <div class="progress  vertical bottom progress-v">
                                    <div class="progress-bar bar-chart" role="progressbar" data-transitiongoal="90"></div>
                                </div>
                                <span class="label-v">OPPORTUNITY</span>
                            </div>
                            <div style="" class="chart-v-item">

                                <span class="percent-v update-v"></span>
                                <div class="progress  vertical bottom progress-v">
                                    <div class="progress-bar bar-chart" role="progressbar" data-transitiongoal="85"></div>
                                </div>
                                <span class="label-v">SAVE TIME</span>
                            </div>
                            <div style="" class="chart-v-item">

                                <span class="percent-v update-v"></span>
                                <div class="progress  vertical bottom progress-v">
                                    <div class="progress-bar bar-chart" role="progressbar" data-transitiongoal="100"></div>
                                </div>
                                <span class="label-v">INCOME</span>
                            </div>


                        </div> <!-- End chart -->
                      </div> <!-- End chart container -->
                    </div> <!-- End col -->
                    <div class="col-sm-4 col-md-6 col-lg-6 hidden-xs thumbs-img-for-chart ">
                          <img src="<?php echo base_url(); ?>assets/frontend/images/Commitment/1.png" class="img-responsive" alt="Image">
                    </div> <!-- End row -->
              </div>
            </div> <!-- End row -->
        </div> <!-- End container -->
    </section> <!-- End section -->

    <!-- Section Text 3 Column-->
    <section class="bg-grey">
            <div class="container">
               <div class="row">
                  <div class="col-md-12">

                      <h2 class="title">We Makes It Easy</h2>
                      <div class="clearfix"></div>
                      <div class="row">
                        <div class="three-column-text clearfix">
                          <div class="col-md-4">
                            <div class="make-easy-item">
                               <h4>Whatever</h4>
                               <p>Maecenas et varius mauris, in viverra urna. Praesent eu lacinia lacus. Nam ac velit vitae justo congue dignissim dignissim vitae nulla. Donec quis leo lorem. Morbi bibendum vehicula nibh id sodales. Vivamus in vestibulum magna, ut lobortis neque. </p>
                            </div>
                          </div><!-- end col -->
                          <div class="col-md-4">
                            <div class="make-easy-item">
                              <h4>Wherever</h4>
                              <p>In placerat sapien urna, quis faucibus metus lacinia commodo. Integer feugiat ullamcorper risus, sed efficitur velit dignissim at. Donec tincidunt elit a neque venenatis varius. Phasellus eget tempor est. Vivamus ut cursus ligula. </p>
                            </div>
                          </div><!-- end col -->
                          <div class="col-md-4">
                            <div class="make-easy-item">
                              <h4>Whenever</h4>
                              <p>Cras non odio tempus, euismod eros eget, venenatis ligula. Nullam augue sem, tincidunt sed elit ac, mollis eleifend justo. Aliquam non magna ac risus lacinia lacinia quis eu justo. Praesent a tempus ante. Etiam ac turpis finibus, aliquam augue quis, feugiat est.</p>
                            </div>
                          </div><!-- end col -->
                        </div> <!-- End 3 column text -->


                      </div><!-- End row -->
                  </div><!-- End col12 -->
              </div><!-- End row -->
            </div><!-- End Container -->
    </section><!-- End Section -->

    <!-- Component Get a Call Back-->
    <section class="bg-dark">
            <div class="container">
                 <div class="row">
                  <div class="get-call-back-contain">
                    <div class="col-md-6 get-call-back-left">
                      <div class="call-back-text">
                        <h2 class="text-white">Get a Call Back</h2>
                        <div class="clearfix"></div>
                        <p class="text-grey">If you need to speak to us about a general query fill in<br> the form below and we will call you back within the<br> same working day.</p>
                      </div><!-- End call back text left -->
                    </div>
                    <div class="col-md-6 get-call-back-right">
                      <div class="call-back-form">
                        <form action="GET" method="POST">
                          <p>How can we help? *</p>

                          <select class="form-control custom-form custom-select">
                            <option selected="selected">Discussions with Financial Experts</option>
                            <option>Meet Finance Assistant - PR Agency </option>
                            <option>Discussions with Senior Finance Manager</option>
                            <option>Designer</option>
                            <option>Our CEO Finanace Theme Group</option>
                          </select>
                          <div class="row">
                            <div class="form-group col-md-6 custom-form">
                              <input type="text" class="form-control" id="name" placeholder="Your Name: *">
                            </div>
                            <div class="form-group col-md-6 custom-form">
                              <input type="text" class="form-control" id="phone" placeholder="Phone Number: *">
                            </div>
                          </div>


                          <button type="submit" class="ot-btn large-btn  btn-light btn-submit">Submit</button>
                        </form>
                      </div><!-- End call back form -->
                    </div>
                  </div>
                </div><!-- End row -->
            </div><!-- End container -->
    </section><!-- End Section -->

     <!-- Component Our Experts Owl -->
    <section>
          <div class="container">
              <div class="row">
                  <div class="col-md-12">
                      <h2 class="title">Our Team</h2>
                      <div class="customNavigation">
                        <a class="btn prev-experts"><i class="fa fa-angle-left"></i></a>
                        <a class="btn next-experts"><i class="fa fa-angle-right"></i></a>
                      </div><!-- End owl custom button -->
                      <div id="owl-experts" class="owl-carousel owl-theme owl-experts clearfix">
                        <div class="item item-experts text-center">
                          <div class="expert-img-container">
                              <div class="avatar">
                                <img src="<?php echo base_url(); ?>assets/frontend/images/Experts/1.jpg" class="img-responsive" alt="Image">
                              </div>
                               <a href="https://www.linkedin.com/" class="in-experts">
                                  <i class="fa fa-linkedin"></i>
                              </a>
                          </div> <!-- end expert img container -->


                          <div class="clearfix"></div>
                          <h4 class="">Peter Hart</h4>
                          <p class="job-experts">Chartered Financial Advisor</p>
                        </div><!-- end item -->
                        <div class="item item-experts text-center">
                          <div class="expert-img-container">
                              <a href="https://www.linkedin.com/" class="in-experts">
                                  <i class="fa fa-linkedin"></i>
                              </a>
                              <div class="avatar">
                                <img src="<?php echo base_url(); ?>assets/frontend/images/Experts/2.jpg" class="img-responsive" alt="Image">
                              </div>
                          </div> <!-- end expert img container -->
                          <div class="clearfix"></div>
                          <h4 class="">Betty Lane</h4>
                          <p class="job-experts">Chartered Financial Advisor</p>
                        </div><!-- end item -->
                        <div class="item item-experts text-center">
                          <div class="expert-img-container">
                              <a href="https://www.linkedin.com/" class="in-experts">
                                  <i class="fa fa-linkedin"></i>
                              </a>
                              <div class="avatar">
                                <img src="<?php echo base_url(); ?>assets/frontend/images/Experts/3.jpg" class="img-responsive" alt="Image">
                              </div>
                          </div> <!-- end expert img container -->
                          <div class="clearfix"></div>
                          <h4 class="">Richard Pierce</h4>
                          <p class="job-experts">Certified Public Accountant</p>
                        </div><!-- end item -->
                        <div class="item item-experts text-center">
                          <div class="expert-img-container">
                              <a href="https://www.linkedin.com/" class="in-experts">
                                  <i class="fa fa-linkedin"></i>
                              </a>
                              <div class="avatar">
                                <img src="<?php echo base_url(); ?>assets/frontend/images/Experts/4.jpg" class="img-responsive" alt="Image">
                              </div>
                          </div> <!-- end expert img container -->
                          <div class="clearfix"></div>
                          <h4 class="">Janice Rose</h4>
                          <p class="job-experts">Registered Tax Preparer</p>
                        </div><!-- end item -->
                        <div class="item item-experts text-center">
                          <div class="expert-img-container">
                              <a href="https://www.linkedin.com/" class="in-experts">
                                  <i class="fa fa-linkedin"></i>
                              </a>
                              <div class="avatar">
                                <img src="<?php echo base_url(); ?>assets/frontend/images/Experts/5.jpg" class="img-responsive" alt="Image">
                              </div>
                          </div> <!-- end expert img container -->
                          <div class="clearfix"></div>
                          <h4 class="">Peter Hart</h4>
                          <p class="job-experts">Chartered Financial Advisor</p>
                        </div><!-- end item -->
                        <div class="item item-experts text-center">
                          <div class="expert-img-container">
                              <a href="https://www.linkedin.com/" class="in-experts">
                                  <i class="fa fa-linkedin"></i>
                              </a>
                              <div class="avatar">
                                <img src="<?php echo base_url(); ?>assets/frontend/images/Experts/6.jpg" class="img-responsive" alt="Image">
                              </div>
                          </div> <!-- end expert img container -->
                          <div class="clearfix"></div>
                          <h4 class="">Betty Lane</h4>
                          <p class="job-experts">Chartered Financial Advisor</p>
                        </div><!-- end item -->
                        <div class="item item-experts text-center">
                          <div class="expert-img-container">
                              <a href="https://www.linkedin.com/" class="in-experts">
                                  <i class="fa fa-linkedin"></i>
                              </a>
                              <div class="avatar">
                                <img src="<?php echo base_url(); ?>assets/frontend/images/Experts/7.jpg" class="img-responsive" alt="Image">
                              </div>
                          </div> <!-- end expert img container -->
                          <div class="clearfix"></div>
                          <h4 class="">Richard Pierce</h4>
                          <p class="job-experts">Certified Public Accountant</p>
                        </div><!-- end item -->
                        <div class="item item-experts text-center">
                          <div class="expert-img-container">
                              <a href="https://www.linkedin.com/" class="in-experts">
                                  <i class="fa fa-linkedin"></i>
                              </a>
                              <div class="avatar">
                                <img src="<?php echo base_url(); ?>assets/frontend/images/Experts/8.jpg" class="img-responsive" alt="Image">
                              </div>
                          </div> <!-- end expert img container -->
                          <div class="clearfix"></div>
                          <h4 class="">Janice Rose</h4>
                          <p class="job-experts">Registered Tax Preparer</p>
                        </div><!-- end item -->
                      </div> <!-- End owl container -->
           <a class="mid-btn  btn-main-color default-size-btn margin-top-50" href="#">Read More</a>

                  </div> <!-- End col -->
              </div><!-- End row -->
          </div>
    </section><!-- End container -->



    <!-- Component Our Partners Owl -->
    <section>
          <div class="container">
             <div class="row">
               <div class=" col-sm-12 col-md-12 col-lg-12">
                  <h2 class="title">Our Partners</h2>
              <div class="customNavigation">
                <a class="btn prev-partners"><i class="fa fa-angle-left"></i></a>
                <a class="btn next-partners"><i class="fa fa-angle-right"></i></a>
              </div><!-- End owl button -->

              <div id="owl-partners" class="owl-carousel owl-theme owl-partners clearfix">
                <?php foreach($home_brand AS $key=>$row) { 
                ?>
                  <div class="item">
                      <a href="<?php echo base_url(); ?>partners">
                        <img src="<?php echo $row->image_path ?>" width="210" height="100" xclass="img-responsive" alt="Image">
                      </a>
                  </div>
                <?php } ?>
                
               </div>

              </div><!-- End row partners -->
             </div><!-- End Row -->
          </div>
    </section><!-- End Section -->

